var sql = require('mssql');
module.exports = function () {
    const config = {
        user: 'BD2221019',
        password: 'Foxezq1612',
        database: 'BD',
        server: 'Apolo',
        options: {
            encrypt: false,
            trustServerCertificate: true
        }
    return sql.connect(config),
    }
}