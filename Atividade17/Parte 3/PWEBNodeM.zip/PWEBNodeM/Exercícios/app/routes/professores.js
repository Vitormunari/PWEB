
var dbConnection = require('../config/dbConnection');

module.exports = function(app)
{
    app.get('/informacao/professores', function(req, res)
    {
        //res.render("informacao/professores");
        //const sql = require('mssql');
 
        //const sqlConfig = {
          //  user:'BD2221019',
            //password:'Foxezq1612',
            //database:'BD',
            //server:'Apolo',
            //options: {
            //    encrypt: false,
            //    trustServerCertificate: true // se você não tiver um certificado de servidor configurado
             // }          
        }
 
        async function getProfessores(){
            try{
                const pool=await dbConnection();
                //const pool = await sql.connect(sqlConfig);
 
                const results = await pool.request().query('SELECT * from PROFESSORES');

                res.render('informacao/professores',{profs: results.recordset});
 
                //res.send(results.recordsets);
            }
            catch (err){
                console.log(err);
            }
        }
 
        getProfessores();
    });
}



