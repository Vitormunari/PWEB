//var express = require('express');
//var app=express();//executando o express
//app.listen(3000,function(){
//    console.log("servidor com express foi carregado");
//})

var app=require('./app/config/server');//carregando o modulo do servidor
//var express = require('express');
//var texto = require('./modulo1');//não precisa colocar modulo1.js ele já entende
//var app = express();//executando o express
 
//app.set('view engine','ejs');
 
//app.get('/',function(req,res){
/    res/render("home/index");
//});
//app.get('/formulario_adicionar_usuario',function(req,res){
//    res.render("admin/adicionar_usuario");
//});
//app.get('/informacao/historia',function(req,res){
//    res.render("informacao/historia");
//});
//app.get('/informacao/cursos',function(req,res){
//    res.render("informacao/cursos");
//});
//app.get('/informacao/professores',function(req,res){
//    res.render("informacao/professores");
//});
var app = require('.app/config/server');

var rotaHome = require('./app/routes/home');
rotaHome(app);

var rotaAdicionarUsuario= require('./app/routes/adicionar_usuario');
rotaAdicionarUsuario(app);

var rotaProfessores = require('./app/routes/professores');
rotaProfessores(app);

var rotaHistoria = require('./app/routes/historia');
rotaHistoria(app);

 
app.listen(3000,function(){
    console.log("servidor iniciado");
});