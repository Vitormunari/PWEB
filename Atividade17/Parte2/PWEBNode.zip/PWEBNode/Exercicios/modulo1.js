var texto = "Observe que esta mensagem vem do módulo";
module.exports=texto;