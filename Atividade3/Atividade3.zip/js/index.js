function alertar(){
    alert('Seja bem Vindo!')
}